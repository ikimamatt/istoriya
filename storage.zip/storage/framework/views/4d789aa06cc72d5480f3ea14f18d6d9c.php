<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt</title>
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset("assets/images/logos/favicon.png")); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset("assets/css/styles.min.css")); ?>" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .receipt { max-width: 600px; margin: 0 auto; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        .receipt h1 { text-align: center; font-style: bold; color: #333; }
        .receipt img { display: block; margin: 0 auto; width: 100px; /* Adjust size here */ }
        .receipt .details, .receipt .products { margin-bottom: 20px; }
        .receipt .products table { width: 100%; border-collapse: collapse; }
        .receipt .products table th, .receipt .products table td { padding: 8px; text-align: left; }
        .receipt .products table th { background-color: #f8f9fa; }
        .receipt .footer { text-align: center; margin-top: 30px; font-size: 1.1rem; }
    </style>
</head>
<body>
    <div class="receipt border border-light">
        <h1 class="text-primary text-center text-bold">ISTORIYA CAFE</h1>
        <h3 class="text-center">Struk Kasir</h3>
        <img src="<?php echo e(asset('assets/images/logos/logo1.png')); ?>" alt="Logo">
        <div class="details">
            <p><strong>Kode Order:</strong> <?php echo e($order->order_code); ?></p>
            <p><strong>Nama:</strong> <?php echo e($order->user_name); ?></p>
            <p><strong>Telepon:</strong> <?php echo e($order->phone); ?></p>
            <p><strong>Alamat:</strong> <?php echo e($order->address); ?></p>
            <p><strong>Metode Pengambilan:</strong> <?php echo e(ucfirst($order->pickup_method)); ?></p>
        </div>

        <div class="products">
            <h4>Produk</h4>
            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->product_name); ?></td>
                            <td>Rp<?php echo e(number_format($product->price, 0, ',', '.')); ?></td>
                            <td><?php echo e($product->quantity); ?></td>
                            <td>Rp<?php echo e(number_format($product->price * $product->quantity, 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <h4>Total: <strong>Rp<?php echo e(number_format($order->total, 0, ',', '.')); ?></strong></h4>
        <p class="footer">Terima kasih atas pembelian Anda!</p>
    </div>
    <script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sidebarmenu.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/apexcharts/dist/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/simplebar/dist/simplebar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dashboard.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if(session()->has('success')): ?>
<script>
    Swal.fire({
        title: 'Berhasil!',
        text: '<?php echo e(session('success')); ?>',
        icon: 'success',
        confirmButtonText: 'OK'
    });
</script>
<?php endif; ?>
<script>
    document.getElementById('logout-btn').addEventListener('click', function () {
      Swal.fire({
        title: 'Konfirmasi Logout',
        text: "Apakah Anda yakin ingin keluar?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Keluar',
        cancelButtonText: 'Batal'
      }).then((result) => {
        if (result.isConfirmed) {
          // Redirect ke route logout jika dikonfirmasi
          window.location.href = "<?php echo e(route('logout')); ?>";
        }
      });
    });
  </script>

<?php if(session()->has('error')): ?>
<script>
    Swal.fire({
        title: 'Gagal!',
        text: '<?php echo e(session('error')); ?>',
        icon: 'error',
        confirmButtonText: 'OK'
    });
</script>
<?php endif; ?>
</body>

</html>
<?php /**PATH C:\laragon\www\istoriya\resources\views/admin/receipt.blade.php ENDPATH**/ ?>