<?php $__env->startSection('admin'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-lg d-flex align-items-stretch">
      <div class="card w-100">
        <div class="card-body p-4">
          <h5 class="mb-4 fw-bold">Lihat Profil Cafe</h5>

          <form action="<?php echo e(route('admin.profiles.update', $profiles->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
              <label for="productName" class="form-label">Instagram</label>
              <input type="text" name="instagram" value="<?php echo e($profiles->instagram); ?>" class="form-control" id="productName" required>
            </div>

            <div class="mb-3">
              <label for="productPrice" class="form-label">Tiktok</label>
              <input type="text" name="tiktok" value="<?php echo e($profiles->tiktok); ?>" class="form-control" id="productPrice"  required>
            </div>

            <div class="mb-3">
                <label for="productPrice" class="form-label">Whatsapp</label>
                <input type="text" name="whatsapp" value="<?php echo e($profiles->whatsapp); ?>" class="form-control" id="productPrice"  required>
            </div>
            <div class="mb-3">
                <label for="productPrice" class="form-label">No Telephone</label>
                <input type="text" name="phone" class="form-control" value="<?php echo e($profiles->phone); ?>"id="productPrice"  required>
            </div>


            <div class="d-flex justify-content-between">
              <button type="submit" class="btn btn-primary">Edit</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\istoriya\resources\views/admin/readcompro.blade.php ENDPATH**/ ?>