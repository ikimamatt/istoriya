<?php $__env->startSection('admin'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg d-flex align-items-stretch">
            <div class="card w-100">
                <div class="card-body p-4">
                    <div class="d-flex mb-4 justify-content-between align-items-center">
                        <h5 class="mb-0 fw-bold">Produk</h5>
                        <a href="<?php echo e(route('admin.addproduk')); ?>" class="btn btn-primary btn-sm">Tambah Produk</a>
                    </div>

                    <div class="table-responsive" data-simplebar>
                        <!-- Table -->
                        <div class="table-responsive" data-simplebar>
                            <table id="dataTableHover" class="table table-borderless align-middle text-nowrap">
                                <thead>
                                    <tr>
                                        <th scope="col" class="text-center">ID Produk</th>
                                        <th scope="col" class="text-center">Nama</th>
                                        <th scope="col" class="text-center">Harga</th>
                                        <th scope="col" class="text-center">Kategori</th>
                                        <th scope="col" class="text-center">Stok</th>
                                        <th scope="col" class="text-center">Preorder</th>
                                        <th scope="col" class="text-center">Gambar</th>
                                        <th scope="col" class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($product->product_id); ?></td>
                                        <td class="text-center"><?php echo e($product->name); ?></td>
                                        <td class="text-center">Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></td>
                                        <td class="text-center"><?php echo e($product->categories); ?></td>
                                        <td class="text-center"><?php echo e($product->stock); ?></td>
                                        <td class="text-center"><?php echo e($product->preorder); ?></td>
                                        <td class="text-center">
                                            <?php if($product->image_path): ?>
                                            <img src="<?php echo e(asset('storage/' . $product->image_path)); ?>" alt="Product Image" style="width: 80px; height: 80px;">
                                            <?php else: ?>
                                            <span>Tidak Ada Gambar</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <button class="btn btn-warning btn-sm" onclick="openEditModal(<?php echo e($product); ?>)">
                                                <i class="bi bi-pencil-fill"></i> Edit
                                            </button>
                                            <button class="btn btn-danger btn-sm" onclick="confirmDelete(<?php echo e($product->id); ?>)">
                                                <i class="bi bi-trash-fill"></i> Hapus
                                            </button>
                                            <form id="delete-form-<?php echo e($product->id); ?>" action="<?php echo e(route('admin.produk.delete', $product->id)); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <script>
                                $(function() {
                                    $('#users-table').DataTable({
                                        processing: true,
                                        serverSide: true,
                                        ajax: '/data',
                                        columns: [
                                            { data: 'name', name: 'nama' },
                                            { data: 'email', name: 'email' },
                                            { data: 'created_at', name: 'created_at' },
                                            { data: 'updated_at', name: 'updated_at' }
                                        ]
                                    });
                                });
                            </script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Edit Produk -->
<div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="editProductModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="editProductForm" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="editProductModalLabel">Edit Produk</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="productName" class="form-label">Nama Produk</label>
                        <input type="text" class="form-control" id="productName" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="productPrice" class="form-label">Harga Produk</label>
                        <input type="text" class="form-control" id="productPrice" name="price" required>
                    </div>
                    <div class="mb-3">
                        <label for="productPrice" class="form-label">Jumlah Stok</label>
                        <input required type="number" name="stock" class="form-control" id="productStock" placeholder="Masukkan jumlah stock" required>
                    </div>
                    <div class="mb-3">
                        <label for="productPrice" class="form-label">Preorder</label>
                        <select class="form-select form-select-sm" id="productPreorder" name="preorder" aria-label="Small select example">
                            <option value="ada">Ada</option>
                            <option value="tidak_ada">tidak ada</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="productCategory" class="form-label">Kategori</label>
                        <select class="form-select form-select-sm" name="categories" id="productCategory" required>
                            <option value="" disabled>Pilih kategori produk</option>
                            <option value="coffee">coffee</option>
                            <option value="coffe_moctail">coffe_moctail</option>
                            <option value="fruit_tea">fruit_tea</option>
                            <option value="milk_based">milk_based</option>
                            <option value="signature">signature</option>
                            <option value="donat">donat</option>
                            <option value="brownies">brownies</option>
                            <option value="cheesecake">cheesecake</option>
                            <option value="Milkbun">Milkbun</option>
                            <option value="Pudding">Pudding</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="productImage" class="form-label">Gambar Produk</label>
                        <input class="form-control" accept="image/*" onchange="validateFile(this)" type="file" id="productImage" name="image" accept="image/*">
                        <small class="text-muted">Kosongkan jika tidak ingin mengganti gambar.</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>



<script src="<?php echo e(asset('assets2/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets2/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets2/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets2/js/ruang-admin.min.js')); ?>"></script>
<!-- Page level plugins -->
<script src="<?php echo e(asset('assets2/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets2/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script>
  $(document).ready(function () {
    $('#dataTableHover').DataTable(); // ID From dataTable with Hover
  });
</script>

<script>
    function validateFile(input) {
        const file = input.files[0];
        const fileType = file ? file.type : '';

        // Check if the file is an image
        if (!fileType.startsWith('image/')) {
            Swal.fire({
                icon: 'error',
                title: 'File yang dipilih bukan gambar',
                text: 'Silakan pilih file gambar (.jpg, .jpeg, .png) sebagai bukti pembayaran.',
                confirmButtonText: 'Ok'
            });

            // Clear the input so that the user can select a valid file
            input.value = '';
        }
    }
</script>

<!-- Skrip untuk Modal dan Konfirmasi Hapus -->
<script>
    // Fungsi untuk membuka modal edit dan memuat data produk ke dalam form
    function openEditModal(product) {
    // Mengatur action form sesuai dengan ID produk
    document.getElementById('editProductForm').action = `/admin/produk/${product.id}`;
    document.getElementById('productName').value = product.name;
    document.getElementById('productPrice').value = product.price;
    document.getElementById('productStock').value = product.stock;
    document.getElementById('productPreorder').value = product.preorder;

    document.getElementById('productCategory').value = product.categories;

    // Menampilkan modal
    var editModal = new bootstrap.Modal(document.getElementById('editProductModal'));
    editModal.show();
}

    // Konfirmasi hapus dengan SweetAlert
    function confirmDelete(productId) {
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Anda tidak bisa membatalkan tindakan ini!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal' // Teks tombol batal diubah menjadi "Batal"
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById(`delete-form-${productId}`).submit();
            }
        })
    }
</script>
<?php if(session('success')): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil',
            text: '<?php echo e(session('success')); ?>',
            showConfirmButton: false,
            timer: 1500
        });
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\istoriya\resources\views/admin/produk.blade.php ENDPATH**/ ?>