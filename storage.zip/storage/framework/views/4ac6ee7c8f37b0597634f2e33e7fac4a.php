<?php $__env->startSection('admin'); ?>
<div class="container-fluid">
<div class="row">
  <div class="col-lg d-flex align-items-stretch">
    <div class="card w-100">
      <div class="card-body p-4">
        <div
          class="d-flex mb-4 justify-content-between align-items-center"
        >
          <h5 class="mb-0 fw-bold">Order</h5>

          <div class="dropdown">
            <button
              id="dropdownMenuButton1"
              data-bs-toggle="dropdown"
              aria-expanded="false"
              class="rounded-circle btn-transparent rounded-circle btn-sm px-1 btn shadow-none"
            >
              <i class="ti ti-dots-vertical fs-7 d-block"></i>
            </button>
            <ul
              class="dropdown-menu dropdown-menu-end"
              aria-labelledby="dropdownMenuButton1"
            >
              <li><a class="dropdown-item" href="<?php echo e(route('admin.incomeReport')); ?>">Rekap Pemasukan</a></li>
              </li>
            </ul>
          </div>
        </div>

        <div class="table-responsive" data-simplebar>
          <table  id="dataTableHover" class="table table-borderless align-middle text-nowrap">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Kode Order</th>
                <th scope="col">Pelanggan</th>
                <th scope="col">Total</th>
                <th scope="col">Metode Pengambilan</th>
                <th scope="col">tanggal</th>
                <th scope="col">Aksi</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="fs-3 fw-normal mb-0"><?php echo e($loop->iteration); ?></td>
                        <td class="fs-3 fw-normal mb-0 text-success"><?php echo e($order->order_code); ?></td>
                        <td class="fs-3 fw-normal mb-0"><?php echo e($order->user_name); ?></td>
                        <td class="fs-3 fw-normal mb-0">Rp<?php echo e(number_format($order->total, 0, ',', '.')); ?></td>
                        <td class="fs-3 fw-normal mb-0"><?php echo e(ucfirst($order->pickup_method)); ?></td>
                        <td class="fs-3 fw-normal mb-0"><?php echo e($order->created_at); ?></td>

                        <td class="fs-3 fw-normal mb-0">
                            <!-- Button to trigger modal -->
                            <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#orderModal<?php echo e($order->id); ?>">
                                Lihat/Edit
                            </button>
                            <form action="<?php echo e(route('admin.orders.delete', $order->id)); ?>" method="POST" class="d-inline-block" id="deleteForm<?php echo e($order->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="button" class="btn btn-danger btn-sm delete-btn" data-id="<?php echo e($order->id); ?>">Hapus</button>
                            </form>
                        </td>

                        <!-- Modal -->
                        <div class="modal fade" id="orderModal<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="orderModalLabel<?php echo e($order->id); ?>" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-lg">
                                <div class="modal-content">
                                    <form action="<?php echo e(route('admin.orders.updateWithProducts', $order->id)); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="modal-header bg-light">
                                            <h5 class="modal-title fw-bold" id="orderModalLabel<?php echo e($order->id); ?>">
                                                Edit Order - #<?php echo e($order->order_code); ?>

                                            </h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <!-- Data Order -->
                                            <h5 class="fw-bold">Detail Order</h5>
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label for="user_name" class="form-label">Nama</label>
                                                    <input disabled type="text" class="form-control" id="user_name" name="user_name" value="<?php echo e($order->user_name); ?>" required>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="phone" class="form-label">No telepon</label>
                                                    <input disabled type="text" class="form-control" id="phone" name="phone" value="<?php echo e($order->phone); ?>" required>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="pickup_method" class="form-label">Metode Pengambilan</label>
                                                    <select class="form-select" id="pickup_method" name="pickup_method" required>
                                                        <option value="ambil_sendiri" <?php echo e($order->pickup_method == 'ambil_sendiri' ? 'selected' : ''); ?>>Ambil Sendiri</option>
                                                        <option value="diantar" <?php echo e($order->pickup_method == 'diantar' ? 'selected' : ''); ?>>Diantar</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-12 mb-3">
                                                    <label for="address" class="form-label">Alamat</label>
                                                    <textarea class="form-control" id="address" name="address" rows="3" required><?php echo e($order->address); ?></textarea>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <label for="total" class="form-label">Total</label>
                                                    <input disabled type="number" class="form-control" id="total" name="total" value="<?php echo e($order->total); ?>" required>
                                                </div>
                                            </div>

                                            <!-- Produk Order -->
                                            <h5 class="fw-bold mt-4">Produk yang dibeli</h5>
                                            <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="border rounded p-3 mb-3">
                                                    <h6 class="fw-bold">Produk #<?php echo e($loop->iteration); ?></h6>
                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <label for="product_name_<?php echo e($product->id); ?>" class="form-label">Nama Produk</label>
                                                            <input disabled type="text" name="products[<?php echo e($product->id); ?>][product_name]" id="product_name_<?php echo e($product->id); ?>" class="form-control" value="<?php echo e($product->product_name); ?>" required>
                                                        </div>
                                                        <div class="col-md-3 mb-3">
                                                            <label for="price_<?php echo e($product->id); ?>" class="form-label">Harga</label>
                                                            <input disabled type="number" name="products[<?php echo e($product->id); ?>][price]" id="price_<?php echo e($product->id); ?>" class="form-control" value="<?php echo e($product->price); ?>" required>
                                                        </div>
                                                        <div class="col-md-3 mb-3">
                                                            <label for="quantity_<?php echo e($product->id); ?>" class="form-label">Jumlah</label>
                                                            <input disabled type="number" name="products[<?php echo e($product->id); ?>][quantity]" id="quantity_<?php echo e($product->id); ?>" class="form-control" value="<?php echo e($product->quantity); ?>" required>
                                                        </div>
                                                        <div class="col-md-12 mb-3">
                                                            <label for="note_<?php echo e($product->id); ?>" class="form-label">Catatan</label>
                                                            <textarea name="products[<?php echo e($product->id); ?>][note]" id="note_<?php echo e($product->id); ?>" class="form-control" rows="2"><?php echo e($product->note); ?></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <!-- Payment Proof -->
                                            <h5 class="fw-bold mt-4">Bukti Pembayaran</h5>
                                            <div class="mb-3 text-center">
                                                <label for="payment_proof" class="form-label">Upload Bukti Pembayaran</label>
                                                <div class="mb-3">
                                                    <?php if($order->payment_proof): ?>
                                                        <img src="<?php echo e(asset('storage/' . $order->payment_proof)); ?>" alt="Payment Proof" class="img-fluid mb-3" style="max-height: 300px;">
                                                    <?php else: ?>
                                                        <p class="text-muted">No payment proof uploaded.</p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <a href="<?php echo e(route('admin.orders.receipt', $order->id)); ?>" class="btn btn-secondary btn-sm">Cetak Struk</a>

                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="ti ti-device-floppy"></i> Simpan Perubahan
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<script>
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function(event) {
            const orderId = this.getAttribute('data-id');

            // Show SweetAlert2 confirmation dialog
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data yang dihapus tidak dapat dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    // If confirmed, submit the form
                    document.getElementById('deleteForm' + orderId).submit();
                }
            });
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\istoriya\resources\views/admin/ordering.blade.php ENDPATH**/ ?>