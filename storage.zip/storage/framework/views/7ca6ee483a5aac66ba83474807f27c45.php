<?php $__env->startSection('admin'); ?>
    <div class="container-fluid">
        <!--  Row 1 -->
        <div class="row">
          <div class="col-lg-12 d-flex align-items-strech">
            <div class="card w-100">
              <div class="card-body">
                <div class="d-flex align-items-center text-center justify-content-between mb-10">
                  <div class="text-center">
                    <h5 class="card-title fw-semibold">Halo selamat datang admin!</h5>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.partial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\istoriya\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>